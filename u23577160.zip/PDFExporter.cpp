#include "PDFExporter.h"
    
void PDFExporter::prepareCanvas()
{}
void PDFExporter::renderElements()
{}

void PDFExporter::saveToFile()
{}