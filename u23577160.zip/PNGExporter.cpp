#include "PNGExporter.h"
    
void PNGExporter::prepareCanvas()
{

}

void PNGExporter::renderElements()
{

}

void PNGExporter::saveToFile()
{
    
}
