#include "PNGExporter.h"
#include<iostream>
    
void PNGExporter::saveToFile()
{
    std::cout << "Your PNG file is ready\n"; 

}
