#include "PDFExporter.h"
#include <iostream>
    

void PDFExporter::saveToFile()
{
    std::cout << "Your PDF file is ready\n"; 
}